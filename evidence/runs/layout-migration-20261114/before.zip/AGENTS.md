# Güncel kaynak düzeni

Canonical workspace: E:\Projeler\Ai_Proje_Ofisi

- 2026-11-08 kullanıcı kararı: yeni uygulama geliştirme kökü AiProjeOfisi/ dizinidir; altındaki AGENTS.md uygulanır. GUNCEL/ mevcut A kaynak tabanı ve mimari referansıdır; kaynaklar topluca taşınmaz. GUNCEL/STATE.json yalnız mevcut A tabanını tanımlar.
- company_os/ güncel Python/C, sql/ güncel sıralı native kaynaklardır.
- Test komutu: C:\Python314\python.exe -B GUNCEL/DOGRULA.py
- ARSIV/ tarihsel kanıttır; aktif kaynak veya güncel PASS sayma.
- compatibility/ yalnız kapalı regresyon/tasarım fixture ağacıdır. Eski yayın betiklerini çalıştırma.
- G0 OPEN; runtime NOT_RUN; ilk TEST 0/13. İnsan onayı veya native kabul üretme.
- Eski klasörleri ya da arşivi tekrar güncel kod bağımlılığına dönüştürme.
- Projenin görünen adı AI Proje Ofisi'dir. Ana belge ve TXT adında sürüm zorunludur: AI_PROJE_OFISI_ANA_MIMARI_DOKUMANI_v{architecture_version}-r{revision}.md/.txt. STATE.json sürümü değişince tools/refresh_source.py --docs bu adı ve paket içi bağlantıları günceller; kök giriş bağlantılarını da güncel tut.
- Ana belge kısa mimari girişidir: güncel tasarım, kararlar, kabul sınırları ve kaynak bağlantıları içerir. Geçmiş tam belgeleri ve kaynak kodlarını belgeye gömme. Tam geçmiş ARSIV içinde kayıpsız korunur. Metin şablonu GUNCEL/dokumanlar/ANA_MIMARI_KAYNAK.md, bağlantılı kaynak listesi KAYNAK_REHBERI.md dosyasıdır.
