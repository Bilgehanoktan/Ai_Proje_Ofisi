# Bakım ve değişiklik rehberi

Canonical workspace: E:\Projeler\Ai_Proje_Ofisi
Son güncelleme: 2026-11-14

Bu dosya bakım için başlangıç noktasıdır. Neyi değiştirmek istediğine göre ilgili kodu, nedenini anlatan kaydı ve kontrol yöntemini bulabilirsin. Bütün kaynakların satır satır açıklaması veya tamamlanmış işletim kılavuzu değildir. Ürün henüz gerçek bir işi baştan sona tamamlamış olarak doğrulanmadı.

## Önce hangi belgeye bakmalıyım?

| Sorun veya ihtiyaç | Başlangıç dosyası |
|---|---|
| Proje ne durumda, ne eksik? | [Sade ilerleme tablosu](ILERLEME_TABLOSU.md) |
| Mimari neyi gerektiriyor? | [Bağlayıcı ana mimari](../GUNCEL/dokumanlar/AI_PROJE_OFISI_ANA_MIMARI_DOKUMANI_v0.16.2-r68.md), [hedef tasarım](../GUNCEL/dokumanlar/hedef-mimari-v1/PROJE_TASARIM_DOKUMANI.md) |
| Hangi modül hangi işten sorumlu? | [Ayrıntılı mimari matrisi](UYGULAMA_DURUM_MATRISI.md) |
| Ekranı nasıl açarım, gerçek bağlantı nasıl sağlanır? | [Görev ekranını çalıştırma](presentation/TASK_SCREEN.md) |
| Geliştirmede hangi kurallar geçerli? | [Uygulama talimatları](AGENTS.md) |

## Neyi değiştirmek istiyorsun?

| Alan | Kod veya ayar | Değişikliğin bağlamı ve kontrolü |
|---|---|---|
| Geçici görev ekranındaki alanlar ve yazılar | [tasks.html](presentation/tasks.html) | [Görev ekranı raporu](CODEX_GOREV_EKRANI_20261114.md); son ofis arayüzü değildir. |
| Görev ekranının görünümü | [tasks.css](presentation/tasks.css) | Masaüstü ve mobil birlikte kontrol edilir. |
| Form gönderme, belirsiz istek ve kayıt gösterimi | [tasks.js](presentation/tasks.js) | [Tarayıcı kontrolü](tools/check_task_screen.py); kayıp yanıt otomatik tekrar gönderilmez. |
| Yerel HTTP, oturum/proje eşlemesi ve Kernel bağlantısı | [task_http.py](presentation/task_http.py) | [HTTP/adapter testleri](tests/unit/test_task_http.py). Yetki ve emisyon kontrolü atlanmaz. |
| İlerleme tablosunun içeriği | [ILERLEME_TABLOSU.json](ILERLEME_TABLOSU.json) | Tek sade takip kaynağıdır; Markdown ve tarayıcı görünümü buradan türetilir. |
| İlerleme tablosunun üretimi ve görünümü | [progress.py](presentation/progress.py), [progress.css](presentation/progress.css) | [Kapsam ve çıktı testleri](tests/unit/test_progress.py). Tüm16modül eşlemesi korunur. |
| Sanal ofis sahnesi | [dashboard.html](presentation/dashboard.html), [office-preview.js](presentation/office-preview.js) | [Tasarım kaynakları](presentation/OFIS_TASARIM_KAYNAKLARI.md). Mevcut geometriyi kendiliğinden farklı tasarımla değiştirme. |
| Merkezî işlem ve sonuç gönderimi | [command_host.py](company_os/command_host.py) | Native DB yetkisi, işlem ve gönderim tekrar kontrolü buradadır; UI yetki üretmez. |
| Başlangıç kaydı ve kaydın okunması | [provisioning.py](company_os/provisioning.py), [bootstrap_readback.py](company_os/bootstrap_readback.py) | [Root okuyucusu düzeltmesi](CODEX_ROOT_READER_20261113.md), [native dar okuma](CODEX_NATIVE_READBACK_ACL_20261113.md). |
| Başlangıç izninin güncelliği | [bootstrap_window.py](company_os/bootstrap_window.py) | [Mevcut native saat/root kontrolüne bağlantı](CODEX_CURRENT_WINDOW_20261113.md). Genel ajan çalışma yetkisi değildir. |
| Ajan/model/araç akışının bağlanması | [workflow.py](company_os/workflow.py), [engine_bridge.py](company_os/engine_bridge.py), [tool_broker.py](company_os/tool_broker.py) | [Kalan işler](KALAN_ISLER_20261113.md); gerçek runtime bağlantıları açık. |
| Bağımsız sonuç doğrulama | [runtime_verification.py](company_os/runtime_verification.py), [supervisor_service.py](company_os/supervisor_service.py) | [Servis/verifier kaydı](CODEX_SERVIS_VERIFIER_20261112.md). Test fixtureı gerçek kabul değildir. |
| Veritabanı kaynak sırası | [assembly.json](sql/assembly.json), [SQL açıklaması](sql/README.md) | Kaynaklar inerttir; DESIGN_ONLY/ROLLBACK engelleri otomatik migrationa çevrilmez. |

## Son değişikliklere nasıl ulaşırım?

- [Görev ekranı ve HTTP bağlantısı — 14 Kasım](CODEX_GOREV_EKRANI_20261114.md)
- [Başlangıç izninin güncellik kontrolü — 13 Kasım](CODEX_CURRENT_WINDOW_20261113.md)
- [Doğru UUID kaydının reddedilmesi düzeltmesi — 13 Kasım](CODEX_ROOT_READER_20261113.md)
- [Dar native okuma yetkisi — 13 Kasım](CODEX_NATIVE_READBACK_ACL_20261113.md)

Bunlar seçilmiş son kayıtlardır; tam sürüm geçmişi değildir. İlgili rapor hangi dosyanın değiştiğini, neden değiştiğini, yapılan kontrolü ve açık sınırları anlatır. Ham test kayıtları ve dosya hash manifestleri `evidence/` altındadır. Eski PASS güncel davranış garantisi değildir. Bu çalışma alanında Git deposu/uzak repo doğrulanmadığından belgeler tam Git geçmişinin yerine geçmez.

## Değişiklikten sonra ne yapılır?

1. İlgili mimari kuralı ve owning kodu oku; bütün arşivi taramak gerekmez.
2. Değişen davranışı, nedenini ve etkilenen dosyaları kısa bir değişiklik kaydına yaz.
3. Değişikliğe uygun kontrolü çalıştır; çalıştırılmayan veya başarısız kontrolü açık bırak.
4. İlgili ilerleme satırını, tarihini ve kanıtını güncelle. Sadece test sayısı arttı diye ürün tamamlandı yazma.
5. Yeni alan/dosya veya önemli davranış değiştiyse bu rehberi güncelle. Kullanıcıya ne çalışıyor/ne eksik/katkı biçiminde anlat.

### Sık kullanılan yerel komutlar

AiProjeOfisi dizininden:

```powershell
C:\Python314\python.exe -B -m presentation.task_http --port 8766
C:\Python314\python.exe -B -m presentation.progress
C:\Python314\python.exe -B -m unittest tests.unit.test_progress tests.unit.test_task_http -v
```

Tarayıcı kontrolü,8766 sunucusu açıkken `C:\Python314\python.exe -B tools/check_task_screen.py` ile çalışır. Bu kontrolün başarılı gönderim senaryoları mocked HTTP kullanır; gerçek ajan işi değildir. Kaynak regresyonu `tools/verify_source.py` ile ayrı çalıştırılır. Loopback bağlantıları ortamın iznini gerektirebilir. Sunucunun açılması DB/oturum/ajan kurulumu anlamına gelmez. Anahtar, parola, bağlantı sırrı ve gerçek token belgelere yazılmaz.


## 2026-11-14 — Kullanıcının istediği tahmini yüzdeler

İlerleme JSONunda alan başına `estimated_percent` kaba uzman tahminidir; ölçülmüş iş listesi veya teknik kabul sonucu değildir. `presentation/progress.py`14alanı eşit ağırlıkla ortalayıp en yakın5puana yuvarlar:ilk özet yaklaşık%25. Belirsizlik%20–40;gerçek ilk akış kabulü ayrı0/13(%0). Alanlar farklı efor taşıdığından bu ortalama kalan süreyi veya kesin tamamlanmayı vermez. Yeni kanıtla tahmin değişebilir/düşebilir. Kullanıcı bu tahmini gösterimi açıkça istedi;AGENTS kuralı güncellendi.2görünüm/veri testi PASS ve gerçek yerel sayfada14satır/özet kontrolü PASS;ürün suite yeniden koşulmadı.


## 2026-11-14 — Mevcut veritabanına ekran bağlantısı

Başlatıcı:[kernel_binding.py](presentation/kernel_binding.py). Scope/ref ve pin alanları:[çalıştırma rehberi](presentation/TASK_SCREEN.md). Neden/nasıl ve sınırlar:[bağlantı raporu](CODEX_KERNEL_BAGLANTISI_20261114.md). Testler:[test_kernel_binding.py](tests/unit/test_kernel_binding.py),native fixture:[native_http_binding_fixture.py](tools/native_http_binding_fixture.py). Gerçek onaylı profil/token bu göreve eklenmedi;başarılı metadata kontrolü gerçek iş kabulü değildir.


## 2026-11-14 — Oturum açma rol atamaz

Kod:[session_provisioning.py](company_os/session_provisioning.py). Mevcut membership/kind/role gerektirir;membership ve grant yaratmaz. Başlangıç nesli/güvenilir saat ve scope kilit kimlikleri tekrar doğrulanır. Caller transaction/commit/rollback ve fiziksel kimlik doğrulamasını yönetir. Oturum talebinde eksik rolü INSERT ederek tamamlama. Neden/önce-sonra ve sınır:[oturum raporu](CODEX_OTURUM_SINIRLARI_20261114.md);testler:[test_session_provisioning.py](tests/unit/test_session_provisioning.py). Yerel kurulum gözlemi kaynaklarda belirtilen konumlarla sınırlıdır,tüm makinede kurulum yokluğu iddiası değildir.


## 2026-11-14 — Yerel boş PostgreSQL temeli

[Kontrol/başlat/durdur rehberi](YEREL_VERITABANI.md);araçlar:[local_postgres.py](tools/local_postgres.py),[Windows yönetim girişi](tools/manage_local_postgres.ps1);[kurulum kanıtı](CODEX_YEREL_POSTGRES_20261114.md). Dedicated hedef /var/lib/ai-proje-ofisi-local;mevcut testdatayla karıştırma. Data silme/prepare/initialize tekrar çalıştırma yok;gerekirse yalnız start/inspect kullan. Uygulama SQL,rol ve oturumları henüz kurulmadı.
