# Proje ilerleme tablosu

Son güncelleme: 2026-11-14

Görev ekranı ve ayrı boş yerel veritabanı çalışıyor; gerçek bir işin baştan sona yapılıp teslim edilmesi henüz doğrulanmadı.

**Tahmini geliştirme: ~%30** · İlk gerçek iş akışının kabulü: **%0 (0/13)**.

Kaba geliştirme tahmini: alanlar eşit ağırlıklı değerlendirilir, ortalama en yakın5puana yuvarlanır. Efor/zaman ağırlıklı veya denetlenmiş tamamlanma ölçümü değildir. Genel belirsizlik aralığı%20–40; yeni kanıtla oran düşebilir. Test sayısından türetilmez.

Bu tablo 16 mimari modülün tamamını sade başlıklarla kapsar. Kaynak: `ILERLEME_TABLOSU.json`. Her anlamlı geliştirmede ilgili satır, tarihi ve kanıtı güncellenir. Kod veya parça testi, gerçek ürün kabulü değildir. Belirsiz alanlar tamamlanmış sayılmaz. Yüzdeler kullanıcının istediği kaba tahminlerdir; ölçülmüş kabul değildir.

| Alan | Tahmini gelişim | Durum | Hazır olan | Eksik olan | Sıradaki iş |
|---|---|---|---|---|---|
| Ön yüz (Frontend) | ~%25 | Geçici ekran çalışıyor | Görev ekranı ve sanal ofis önizlemesi açılıyor. | Son ofis arayüzü ve canlı görev verisi eksik. | Görev ekranını gerçek kayıtlarla beslemek. |
| Arka uç (Backend) | ~%45 | Kısmen hazır | Ekranı mevcut veritabanına bağlayan denetimli başlatıcı hazır; izole native ortamda yetkisiz istek reddi doğrulandı. | Onaylı gerçek bağlantı ayarı ve oturumla kalıcı iş kaydı henüz doğrulanmadı. | Onaylı bağlantı ve oturumla ilk gerçek iş isteğini kaydetmek. |
| Veritabanı | ~%50 | Boş yerel veritabanı çalışıyor | Ayrı PostgreSQL ve boş veritabanı kuruldu; yerel erişim ve yeniden başlatma doğrulandı. | Uygulama tabloları, başlangıç yetkileri ve gerçek iş kayıtları henüz yok. | Mimariye uygun uygulama şeması ve yetkili bağlantıyı hazırlamak. |
| Güvenlik (Security) | ~%35 | Kısmen hazır | Oturum açarken rol eklenmiyor; mevcut rol, güncel başlangıç kaydı, güvenilir süre ve proje kilidi kontrol ediliyor. | Gerçek kimlik, oturum ve güvenilir çalışma ortamıyla uçtan uca kullanım doğrulanmadı. | Geçerli oturumla erişim ve iptal senaryosunu doğrulamak. |
| Ajanlar ve iş yönetimi | ~%25 | Gerçek çalışma doğrulanmadı | Planlama ve görev dağıtımının kod parçaları mevcut. | Görev alan ve işi bitiren gerçek ajan akışı gösterilmedi. | İlk işi plan ve çalıştırılabilir göreve dönüştürmek. |
| Yerel yapay zekâ modeli | ~%20 | Gerçek bağlantı doğrulanmadı | Model bağlantısı için adapter kodu var. | Seçilmiş yerel modelle görev üretimi doğrulanmadı. | Ücretsiz yerel modeli mevcut görev akışına bağlamak. |
| Dosyalar ve araçlar | ~%35 | Kısmen hazır | Dosya değişikliği ve araç kullanımını sınırlayan kod var. | Gerçek görevde güvenli dosya değişikliği ve teslim açık. | Tek dosyalık değişikliği kayıtlarıyla üretmek. |
| Sonuç kontrolü ve kabul | ~%40 | Kısmen hazır | Ayrı doğrulayıcı, test ve sonuç kontrolü kodu var. | Gerçek ajanın ürettiği dosyanın bağımsız kabulü açık. | İlk gerçek çıktıyı bağımsız kontrol ettirmek. |
| Canlı durum ve olaylar | ~%20 | Gerçek bağlantı doğrulanmadı | Yetkili kayıt okuma ve olay sözleşmeleri mevcut. | Panelde canlı görev/ajan ilerlemesi gösterilmiyor. | Kalıcı kayıtları ve güncellemeleri panelde göstermek. |
| Katalog ve ürün hafızası | ~%10 | Kabulü doğrulanmadı | Mimaride katalog, kaynak ve erişim kuralları tanımlı. | Ürünün kendi hafıza/katalog akışı gerçek ortamda doğrulanmadı. | İlk iş akışından sonra kalıcı katalog ve erişim bağlarını tamamlamak. |
| Diğer iş türleri | ~%10 | İlk yazılım işi bekleniyor | Yazılım ve sonraki iş türlerinin kapsamı tanımlı. | İlk yazılım teslimi; ardından araştırma, tablo ve yükümlülük akışları açık. | Önce ilk yazılım işini tamamlamak. |
| Bütçe ve dış işlemler | ~%10 | Kabulü doğrulanmadı | Bütçe ve dış etki sınırları mimaride tanımlı. | Gerçek bütçe kaydı ve dış işlem mutabakatı doğrulanmadı. | Mevcut mimari sırasıyla bütçe ve işlem kayıtlarını bağlamak. |
| Kurulum, yedek ve kurtarma | ~%35 | Yerel temel kuruldu | Ayrı veritabanı için güvenli başlat/durdur/durum araçları var; veriler yeniden başlatmada korunuyor. | Uygulama kurulumu, otomatik açılış, yedekleme ve kurtarma henüz tamamlanmadı. | Uygulama şemasını ve gerekli kimlik/yetki kayıtlarını hazırlamak. |
| Testler ve teslim kalitesi | ~%35 | Parça testleri geçiyor | Bakım rehberi var. Son tam kaynak koşumu: Linux248 geçti; Windows228 geçti,20 atlandı. | Tüm ürünün gerçek uçtan uca testi ve insan kabulü açık. | İlk gerçek görev için baştan sona kanıt oluşturmak. |

## Kontrol ve kanıt tarihleri

- **Ön yüz (Frontend)** — 2026-11-14; MOD-011. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [CODEX_GOREV_EKRANI_20261114.md](CODEX_GOREV_EKRANI_20261114.md)
- **Arka uç (Backend)** — 2026-11-14; MOD-001, MOD-002. Bağlantı başlatıcısı ve native sentetik HTTP ret deneyi doğrulandı;gerçek yetkili görev kaydı doğrulanmadı. Kanıt: [CODEX_GOREV_EKRANI_20261114.md](CODEX_GOREV_EKRANI_20261114.md), [CODEX_KERNEL_BAGLANTISI_20261114.md](CODEX_KERNEL_BAGLANTISI_20261114.md)
- **Veritabanı** — 2026-11-14; MOD-001, MOD-016. Ayrı boş PostgreSQL temeli,peer ret ve restart kalıcılığı doğrulandı;uygulama/insan kabulü verilmedi. Kanıt: [CODEX_CURRENT_WINDOW_20261113.md](CODEX_CURRENT_WINDOW_20261113.md), [CODEX_YEREL_POSTGRES_20261114.md](CODEX_YEREL_POSTGRES_20261114.md)
- **Güvenlik (Security)** — 2026-11-14; MOD-001, MOD-004. Oturum kodu ve native plan/eksik-root reddi doğrulandı;gerçek kurulum/oturum kabulü verilmedi. Kanıt: [CODEX_CURRENT_WINDOW_20261113.md](CODEX_CURRENT_WINDOW_20261113.md), [CODEX_OTURUM_SINIRLARI_20261114.md](CODEX_OTURUM_SINIRLARI_20261114.md)
- **Ajanlar ve iş yönetimi** — 2026-11-14; MOD-002, MOD-003. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Yerel yapay zekâ modeli** — 2026-11-14; MOD-005. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Dosyalar ve araçlar** — 2026-11-14; MOD-006, MOD-007. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Sonuç kontrolü ve kabul** — 2026-11-14; MOD-008, MOD-009. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Canlı durum ve olaylar** — 2026-11-14; MOD-010. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [CODEX_GOREV_EKRANI_20261114.md](CODEX_GOREV_EKRANI_20261114.md)
- **Katalog ve ürün hafızası** — 2026-11-14; MOD-012. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Diğer iş türleri** — 2026-11-14; MOD-013. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Bütçe ve dış işlemler** — 2026-11-14; MOD-014. Son raporlarla eşleme; bu tablo hazırlanırken ürün testleri tekrar çalıştırılmadı. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md)
- **Kurulum, yedek ve kurtarma** — 2026-11-14; MOD-015. Ayrı boş PostgreSQL temeli,peer ret ve restart kalıcılığı doğrulandı;uygulama/insan kabulü verilmedi. Kanıt: [KALAN_ISLER_20261113.md](KALAN_ISLER_20261113.md), [CODEX_KERNEL_BAGLANTISI_20261114.md](CODEX_KERNEL_BAGLANTISI_20261114.md), [CODEX_OTURUM_SINIRLARI_20261114.md](CODEX_OTURUM_SINIRLARI_20261114.md), [CODEX_YEREL_POSTGRES_20261114.md](CODEX_YEREL_POSTGRES_20261114.md)
- **Testler ve teslim kalitesi** — 2026-11-14; MOD-016. Ayrı boş PostgreSQL temeli,peer ret ve restart kalıcılığı doğrulandı;uygulama/insan kabulü verilmedi. Kanıt: [CODEX_GOREV_EKRANI_20261114.md](CODEX_GOREV_EKRANI_20261114.md), [BAKIM_VE_DEGISIKLIK_REHBERI.md](BAKIM_VE_DEGISIKLIK_REHBERI.md), [CODEX_KERNEL_BAGLANTISI_20261114.md](CODEX_KERNEL_BAGLANTISI_20261114.md), [CODEX_OTURUM_SINIRLARI_20261114.md](CODEX_OTURUM_SINIRLARI_20261114.md), [CODEX_YEREL_POSTGRES_20261114.md](CODEX_YEREL_POSTGRES_20261114.md)

İlk çalışan yazılım işi ara teslimdir; tam 16 modül/PH-00–PH-06 kapsamı korunur. G0 OPEN; first13 0/13. Bu tablo yetki veya kabul üretmez.
