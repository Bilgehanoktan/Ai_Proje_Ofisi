"""Ortak uygulama paketleri."""
