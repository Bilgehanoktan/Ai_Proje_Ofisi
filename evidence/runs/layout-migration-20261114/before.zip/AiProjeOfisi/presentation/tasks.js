'use strict';
const $ = id => document.getElementById(id);
const pendingKey = 'aipof.pending-objective';
let configured = false;
let uncertain = sessionStorage.getItem(pendingKey);
function showPending(id) {
  $('feedback').textContent = 'Bu isteğin kaydedilip kaydedilmediği henüz bilinmiyor. Aynı işi yeniden göndermeden önce kayıt durumu kontrol edilmeli.';
  $('request-ref').hidden = false;
  $('request-ref').textContent = 'İstek numarası: ' + id;
  $('request-fields').disabled = true;
}
async function post(path, body) {
  const response = await fetch(path, {method:'POST', credentials:'omit', cache:'no-store',
    headers:{'Content-Type':'application/json','Authorization':'Bearer '+$('session').value},
    body:JSON.stringify(body)});
  const value = await response.json();
  return {ok:response.ok, code:response.status, value};
}
async function initialize() {
  try {
    const response = await fetch('/api/connection', {cache:'no-store'});
    if (!response.ok) throw new Error();
    const state = await response.json();
    configured = state.configured === true;
    $('connection').textContent = configured ? 'Görev bağlantısı tanımlı' : 'Görev altyapısı bağlı değil';
    $('availability').textContent = configured
      ? 'Yetkili oturumunla iş isteği gönderebilirsin. Kaydın alınması, işin başladığı anlamına gelmez.'
      : 'Ekran hazır. Gerçek görev altyapısı henüz bağlı olmadığı için şu anda iş gönderilemiyor.';
    $('request-fields').disabled = !configured || !!uncertain;
    $('read-fields').disabled = !configured;
  } catch (_) {
    $('connection').textContent = 'Bağlantı kurulamadı';
    $('availability').textContent = 'Sunucuya ulaşılamıyor. Bağlantı gelene kadar yeni istek gönderilemez.';
  }
  if (uncertain) showPending(uncertain);
}
$('request-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (!configured || uncertain) return;
  if (!$('goal').value.trim() || !$('constraints').value.trim() || !$('outputs').value.trim()) return;
  const id = crypto.randomUUID();
  const body = {request_id:id, goal:$('goal').value.trim(),
    constraints:[$('constraints').value.trim()],expected_outputs:[$('outputs').value.trim()]};
  // Persist only the request ID, never bearer/goal. A refresh during a lost
  // acknowledgement must not silently generate a new idempotency key.
  uncertain = id;
  sessionStorage.setItem(pendingKey,id);
  $('submit').disabled = true;
  $('feedback').textContent = 'İstek gönderiliyor…';
  try {
    const response = await post('/api/objectives',body);
    if (!response.ok) {
      if (response.code === 409 || response.code >= 500) {showPending(id); return;}
      uncertain = null; sessionStorage.removeItem(pendingKey);
      $('feedback').textContent = response.code === 401 ? 'Geçerli bir oturum anahtarı gerekli.'
        : response.code === 403 ? 'Bu işlem için yetki doğrulanamadı. İstek başarıyla kaydedildi olarak gösterilmedi.'
        : 'İstek gönderilemedi. Alanları kontrol et.';
      return;
    }
    const receipt = response.value.command_receipt;
    if (response.value.semantics !== 'AUTHORIZED_FACT_NOT_CURRENT_STATE' || !receipt || !receipt.command_id) {
      showPending(id); return;
    }
    uncertain = null; sessionStorage.removeItem(pendingKey);
    $('receipt').hidden = false;
    $('receipt-id').textContent = receipt.command_id;
    $('request-state').textContent = 'İş isteği kaydedildi. Ajanın çalışmasına ilişkin kayıt henüz gösterilmedi.';
    $('stage-request').classList.add('recorded');
    $('feedback').textContent = 'İş isteği kaydedildi. Henüz tamamlanmış bir iş veya teslim yok.';
  } catch (_) {showPending(id);}
  finally {$('session').value=''; $('submit').disabled=!!uncertain;}
});
$('read-form').addEventListener('submit', async event => {
  event.preventDefault();
  if (!configured) return;
  $('record').hidden = true;
  $('read-feedback').textContent = 'Kayıt sorgulanıyor…';
  try {
    const response = await post('/api/details',{resource:$('resource').value,
      task_id:$('task-id').value.trim(), record_id:$('record-id').value.trim(),
      attempt_id:null, expected_digest:null, ui_generation:0});
    if (!response.ok) { $('read-feedback').textContent='Kayıt okunamadı. Oturumu, yetkini ve kayıt numaralarını kontrol et.';return; }
    if (response.value.semantics !== 'AUTHORIZED_FACT_NOT_CURRENT_STATE' || !response.value.result?.record) throw new Error();
    const record=response.value.result.record;
    const states={DRAFT:'Taslak',READY:'Çalışmaya hazır',RUNNING:'Çalışıyor',
      WAITING_APPROVAL:'Onay bekliyor',VERIFYING:'Sonuç kontrol ediliyor',
      CHANGES_REQUIRED:'Düzeltme gerekiyor',BLOCKED:'Bir engel nedeniyle durdu',
      ACCEPTED:'Kabul edildi',FAILED:'Başarısız oldu',CANCELLED:'İptal edildi',
      PRODUCED:'Çıktı üretildi. Kabul sonucu ayrıca kontrol edilmeli.'};
    $('record-state').textContent=Object.hasOwn(states,record.state)
      ? states[record.state] : 'Bu kayıtta açıklanmış bir çalışma durumu bulunmuyor.';
    $('record-title').textContent=typeof record.title==='string' ? record.title : '';
    $('record-raw').textContent=JSON.stringify(record,null,2);
    $('record').hidden=false;
    $('read-feedback').textContent='Kayıt yeniden okundu. Bu sonuç sorgu anına aittir; canlı çalışma göstergesi değildir.';
  } catch (_) {$('read-feedback').textContent='Kayıt alınamadı. Başarılı bir sonuç gösterilmiyor.';}
});
initialize();
