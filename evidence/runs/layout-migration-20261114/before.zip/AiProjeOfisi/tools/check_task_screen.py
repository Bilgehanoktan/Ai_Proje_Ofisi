"""Browser checks: live unconfigured page; explicitly mocked transport cases.

No real token/DB/worker is used. Screenshots are the live unconfigured screen.
"""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

ROOT=Path(__file__).resolve().parents[1]
EVIDENCE=ROOT/'evidence'


def main():
    report={'scope':'LIVE_UNCONFIGURED_UI_AND_MOCK_HTTP_NOT_RUNTIME_ACCEPTANCE'}
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(headless=True)
        page=browser.new_page(viewport={'width':1440,'height':1050})
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.goto('http://127.0.0.1:8766',wait_until='networkidle')
        assert page.get_by_role('heading',name='Birlikte yapacağımız iş').is_visible()
        assert page.locator('#connection').inner_text()=='Görev altyapısı bağlı değil'
        assert page.get_by_role('button',name='İş isteğini gönder').is_disabled()
        page.screenshot(path=str(EVIDENCE/'TASK_SCREEN_20261114_desktop.png'),full_page=True)
        page.set_viewport_size({'width':390,'height':844})
        assert page.evaluate('document.documentElement.scrollWidth<=innerWidth')
        page.screenshot(path=str(EVIDENCE/'TASK_SCREEN_20261114_mobile.png'),full_page=True)
        report['live_unconfigured_desktop_mobile']='PASS'
        page.set_viewport_size({'width':1440,'height':1050})
        page.get_by_role('link',name='Sanal ofis önizlemesi').click()
        page.wait_for_selector('#role-list button',state='attached')
        page.get_by_role('tab',name='Ajanlar',exact=True).click()
        page.locator('#role-list button').filter(has_text='Research').click()
        assert page.locator('#role-title').inner_text()=='Research'
        page.get_by_role('link',name='Görevler',exact=True).click()
        report['existing_office_navigation_and_script']='PASS'
        page.route('**/api/connection',lambda route:route.fulfill(json={'configured':True,'execution_verified':False}))
        calls=[]
        def unknown(route):
            calls.append(route.request.post_data_json)
            route.fulfill(status=409,json={'error':'OUTCOME_UNKNOWN_DO_NOT_RESUBMIT'})
        page.route('**/api/objectives',unknown)
        page.reload(wait_until='networkidle')
        page.locator('#goal').fill('Normalize title in the specified file only')
        page.locator('#constraints').fill('Do not change other files')
        page.locator('#outputs').fill('Corrected file and verification result')
        page.locator('#session').fill('fixture-session-not-a-real-secret')
        page.get_by_role('button',name='İş isteğini gönder').click()
        expect(page.locator('#feedback')).to_contain_text('henüz bilinmiyor')
        assert page.get_by_role('button',name='İş isteğini gönder').is_disabled()
        assert page.locator('#session').input_value()==''
        identifier=page.locator('#request-ref').inner_text()
        page.reload(wait_until='networkidle')
        assert page.locator('#request-ref').inner_text()==identifier
        assert page.get_by_role('button',name='İş isteğini gönder').is_disabled()
        assert page.locator('#session').is_enabled()
        assert len(calls)==1
        assert calls[0]['request_id'] in identifier
        report['mock_unknown_commit_reload_no_resubmit']='PASS'
        page.evaluate('sessionStorage.clear()')
        page.unroute('**/api/objectives')
        def accepted(route):
            calls.append(route.request.post_data_json)
            route.fulfill(json={'semantics':'AUTHORIZED_FACT_NOT_CURRENT_STATE',
                'result':{'id':'fixture-objective'},'command_receipt':{'command_id':'fixture-command'}})
        page.route('**/api/objectives',accepted)
        page.reload(wait_until='networkidle')
        page.locator('#goal').fill('Normalize title in the specified file only')
        page.locator('#constraints').fill('Do not change other files')
        page.locator('#outputs').fill('Corrected file and verification result')
        page.locator('#session').fill('fixture-session-not-a-real-secret')
        page.get_by_role('button',name='İş isteğini gönder').click()
        page.wait_for_selector('#receipt:visible')
        assert page.locator('#receipt-id').inner_text()=='fixture-command'
        assert 'henüz gösterilmedi' in page.locator('#request-state').inner_text()
        assert page.evaluate('sessionStorage.length')==0
        report['mock_receipt_does_not_claim_agent_execution']='PASS'
        page.route('**/api/details',lambda route:route.fulfill(json={
            'semantics':'AUTHORIZED_FACT_NOT_CURRENT_STATE',
            'result':{'record':{'state':'RUNNING','title':'<img src=x onerror=alert(1)>'}}}))
        page.locator('#session').fill('fixture-session-not-a-real-secret')
        page.locator('#task-id').fill('00000000-0000-4000-8000-000000000001')
        page.locator('#record-id').fill('00000000-0000-4000-8000-000000000002')
        page.get_by_role('button',name='Kaydı getir').click()
        expect(page.locator('#record-state')).to_have_text('Çalışıyor')
        assert page.locator('#record-title').inner_text()=='<img src=x onerror=alert(1)>'
        assert page.locator('#record img').count()==0
        report['mock_record_plain_language_and_escaped_text']='PASS'
        assert not errors, errors
        report['browser_page_errors']=errors
        report['status']='PASS'
        browser.close()
    (EVIDENCE/'TASK_SCREEN_20261114_browser.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))


if __name__=='__main__':main()
