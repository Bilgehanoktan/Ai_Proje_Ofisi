"""Read-only CLI entry. Enrolled supervisor owns environment preparation.

No synthetic SQL bootstrap, DB startup, mount, role deletion or fallback worker.
Call disposable_e2e_workflow_trial.main with enrolled in-memory ports from the
trusted supervisor to execute; standalone CLI only reports missing inputs.
"""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
from tools import disposable_e2e_workflow_trial as trial


def main():
    return trial.main()


if __name__ == '__main__':
    raise SystemExit(main())
