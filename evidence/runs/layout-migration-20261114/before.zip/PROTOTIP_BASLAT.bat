@echo off
cd /d "%~dp0GUNCEL\compatibility"
call PROTOTIP_BASLAT.bat
