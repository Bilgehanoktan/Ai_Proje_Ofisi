param([switch]$NoBrowser)
& (Join-Path $PSScriptRoot 'GUNCEL/compatibility/PROTOTIP_BASLAT.ps1') @PSBoundParameters
