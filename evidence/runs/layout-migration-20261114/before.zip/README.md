> Yeni uygulama geliştirme kökü (2026-11-08): [AiProjeOfisi](AiProjeOfisi/README.md). GUNCEL mevcut A kaynak/mimari referansıdır. Yeni kök SCAFFOLD_ONLY; runtime kabulü yoktur.

# AI Proje Ofisi

Güncel kod, sözleşme, SQL ve testler: [GUNCEL](GUNCEL/README.md).

Ana belge: [Güncel proje belgesi](GUNCEL/dokumanlar/AI_PROJE_OFISI_ANA_MIMARI_DOKUMANI_v0.16.2-r68.md).

Doğrulama: `C:\Python314\python.exe -B GUNCEL/DOGRULA.py` veya `DOGRULA.bat`.

Geçmiş: `ARSIV/HISTORY_STORE.sqlite3`; geri yükleme yönergesi GUNCEL/README.md içindedir. Eski kaynak ağacı ARSIV/onceki_kaynaklar altında korunur.

G0 OPEN; runtime NOT_RUN; ilk TEST 0/13. Bu düzenleme gerçek DB/Linux kabulü değildir.
